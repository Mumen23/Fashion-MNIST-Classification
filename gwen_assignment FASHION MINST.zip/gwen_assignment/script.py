import tensorflow as tf
from tensorflow import keras
import numpy as np
import matplotlib.pyplot as plt

# Load Fashion MNIST dataset
(train_images, train_labels), (test_images, test_labels) = keras.datasets.fashion_mnist.load_data()

# Normalize images
train_images, test_images = train_images / 255.0, test_images / 255.0

# Class labels
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat', 
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

# Build CNN model
model = keras.Sequential([
    keras.layers.Conv2D(32, (3,3), activation='relu', input_shape=(28, 28, 1)),
    keras.layers.MaxPooling2D(2,2),
    keras.layers.Conv2D(64, (3,3), activation='relu'),
    keras.layers.MaxPooling2D(2,2),
    keras.layers.Conv2D(128, (3,3), activation='relu'),
    keras.layers.Flatten(),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dense(10, activation='softmax')
])

# Compile model
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Train model
model.fit(train_images[..., np.newaxis], train_labels, epochs=10, validation_split=0.1)

# Evaluate model
test_loss, test_acc = model.evaluate(test_images[..., np.newaxis], test_labels)
print(f'\nTest accuracy: {test_acc:.4f}')

# Make predictions on two test images
sample_images = test_images[:2]
predictions = model.predict(sample_images[..., np.newaxis])

# Display predictions
for i, img in enumerate(sample_images):
    plt.imshow(img, cmap=plt.cm.binary)
    plt.title(f'Predicted: {class_names[np.argmax(predictions[i])]}')
    plt.show()

# Save model
model.save('fashion_mnist_cnn.h5')